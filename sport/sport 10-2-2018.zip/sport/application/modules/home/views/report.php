<link rel="stylesheet" type="text/css" href="">

<div style="margin: auto; max-width:500px;">
    <div style="margin-top:30px;">
        <img src="https://content-static.upwork.com/uploads/2014/10/01073427/profilephoto1.jpg"
                style="border-radius:50%; width:35px; height:35px; display: inline-block; margin:0px; vertical-align:sub;">
        <img src="https://cdn2.iconfinder.com/data/icons/minimalism/512/twitter.png"
                style="border-radius:50%; width:35px; height:35px; display: inline-block; float:right; margin:0px; vertical-align:sub;">
		<h1 style="font-family:Arial">Your Highlights </h1>
    </div>
    
    <div style="height40px; clear:both;"></div>
    
    <div style="border:1px solid #ccc; padding:15px; border-radius: 5px; margin-bottom:20px;">
        <div style="display:inline-block">
            <img src="https://content-static.upwork.com/uploads/2014/10/01073427/profilephoto1.jpg"
                style="border-radius:50%; width:35px; height:35px; display: inline-block; margin:0px; vertical-align:sub;">
        </div>
        <div style="display: inline-block; padding-left:5px;">
            <p style="margin:0px; font-weight: 600; font-family: arial;">BJP</p>
            <p style="margin:0px; color:#657786;">@amit shah</p>
        </div>
        <div>
            <p style="font-family: arial; font-size: 14px;">No mercy for the rapists.</p>
            <div style="width:470px;">
                <img src="https://media.wired.com/photos/598e35fb99d76447c4eb1f28/master/pass/phonepicutres-TA.jpg" style="width:100%;">
            </div>
            <ul style="list-style:none; padding:0px;">
                <li style="width:33%; float:left; margin-right: 0.5%;">
                    <img src="https://media.wired.com/photos/598e35fb99d76447c4eb1f28/master/pass/phonepicutres-TA.jpg" style="width:100%;">
                </li>
                <li style="width:33%; float:left; margin-right: 0.5%;">
                    <img src="https://media.wired.com/photos/598e35fb99d76447c4eb1f28/master/pass/phonepicutres-TA.jpg" style="width:100%;">
                </li>
                <li style="width:33%; float:left;">
                    <img src="https://media.wired.com/photos/598e35fb99d76447c4eb1f28/master/pass/phonepicutres-TA.jpg" style="width:100%;">
                </li>
            </ul>
            <div style="height:10px; clear:both;"></div>
            <div style="display:inline-block;">
                <img src="https://cdn1.iconfinder.com/data/icons/speech-bubbles/24/Speach-Bubble_3-512.png" style="width:15px; vertical-align: text-bottom;">
                130
            </div>
            <div style="display:inline-block; margin-left:30px;">
                <img src="https://image.freepik.com/icones-gratis/coracao-forma-de-contorno_318-32549.jpg" style="width:15px; vertical-align: text-bottom;">
                1.7l
            </div>
        </div>
    </div>
    
    <div style="border:1px solid #ccc; padding:15px; border-radius: 5px; margin-bottom:20px;">
        <div style="display:inline-block">
            <img src="https://content-static.upwork.com/uploads/2014/10/01073427/profilephoto1.jpg"
                style="border-radius:50%; width:35px; height:35px; display: inline-block; margin:0px; vertical-align:sub;">
        </div>
        <div style="display: inline-block; padding-left:5px;">
            <p style="margin:0px; font-weight: 600; font-family: arial;">BJP</p>
            <p style="margin:0px; color:#657786;">@amit shah</p>
        </div>
        <div>
            <p style="font-family: arial; font-size: 14px;">No mercy for the rapists.</p>
            <div style="width:470px;">
            	<iframe src="http://ctinfotech.com/CT06/positive-network/assets/about-us/510a200313d1218ff291daacc1973249.mp4" style="width:100%;"></iframe>
            </div>
            <ul style="list-style:none; padding:0px;">
                <li style="width:33%; float:left; margin-right: 0.5%;">
	                <iframe src="http://ctinfotech.com/CT06/positive-network/assets/about-us/510a200313d1218ff291daacc1973249.mp4" style="width:100%;"></iframe>
                </li>
                <li style="width:33%; float:left; margin-right: 0.5%;">
	                <iframe src="http://ctinfotech.com/CT06/positive-network/assets/about-us/510a200313d1218ff291daacc1973249.mp4" style="width:100%;"></iframe>
                </li>
                <li style="width:33%; float:left;">
	                <iframe src="http://ctinfotech.com/CT06/positive-network/assets/about-us/510a200313d1218ff291daacc1973249.mp4" style="width:100%;"></iframe>
                </li>
            </ul>
            <div style="height:10px; clear:both;"></div>
            <div style="display:inline-block;">
                <img src="https://cdn1.iconfinder.com/data/icons/speech-bubbles/24/Speach-Bubble_3-512.png" style="width:15px; vertical-align: text-bottom;">
                130
            </div>
            <div style="display:inline-block; margin-left:30px;">
                <img src="https://image.freepik.com/icones-gratis/coracao-forma-de-contorno_318-32549.jpg" style="width:15px; vertical-align: text-bottom;">
                1.7l
            </div>
        <div>
    </div>
</div>

