<h1>About</h1>

<h2>Introduction</h2> 
  
<p>Sporto App is its first of the kind. It gives you the freedom to practice sports with who you want wherever you want and whenever you want. With sporto you always have some to play with.</p>

<p>Personally, I see Sporto App as the card you receive at the entrance to an amusement park - just with sporting events instead of carousels.</p>

<p>We have made a platform for all sports lovers, who can now do and participate in local sports events.</p>


<p>Sporto shows you where nearby, other users are ready to play, run, train and cycle with you.
</p>

<p>The concept is about creating freedom for you. We give you control over your active sports life. We hope you will contradict it.</p>



<h3>Example No. 1:</h3>


<p>You are some boys who would like to play some ball. But you are not quite enough to play game. You therefore create an event at Sporto. You get a message every time there are some interested. You decide if you will accept or ignore the requests. After a short while, you are enough players to play a real match.</p>

<h3>Example 2:</h3>

<p>You and your boyfriend would like to play and play badminton. But you do not know anyone else who wants to, and you do not know where to play. You will find Sporto App and find out that Børge and Jenna Sørme also lack a pair to play in courage. You request to play and vupti - then stand down in the hall ready for battle.</p>
